//
//  Constants.swift
//  FriendFinder
//
//  Created by Mitchell Phillips on 2/23/16.
//  Copyright © 2016 Mitchell Phillips. All rights reserved.
//

import Foundation

typealias JSONArray = [JSONDictionary]
typealias JSONDictionary = [String:AnyObject]