//
//  ViewController.swift
//  FriendFinder
//
//  Created by Mitchell Phillips on 2/23/16.
//  Copyright © 2016 Mitchell Phillips. All rights reserved.
//

import UIKit

protocol FriendsProtocol {
    func passInfo(friend: Friend)
}

class ViewController: UIViewController, FriendsProtocol {

    var friendArray = [Friend]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
              
    } // end viewDidLoad
    
    func passInfo(friend: Friend) {
        self.friendArray.append(friend)
    }
} // end class
